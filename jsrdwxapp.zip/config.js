const baseUrl = 'https://jsrdtbapi.vic-net.net'

export default baseUrl